"""Textual memory-api-v1.1 transport; no answering or benchmark lookup.

Ordered text parts are retained in a separate immutable envelope journal. The
retriever receives their ordered text joined by LF. String messages are passed
through byte-for-byte. Only text content is supported by this Textual adapter.
"""
from contextlib import closing
import hashlib
import json
from pathlib import Path
import sqlite3
from typing import Annotated, Literal

from pydantic import BaseModel, ConfigDict, Field, StrictStr, field_validator

from .core import ConflictError, digest

Nonempty = Annotated[StrictStr, Field(min_length=1)]


class TextPart(BaseModel):
    model_config = ConfigDict(extra='forbid')
    type: Literal['text']
    text: Nonempty


Content = Nonempty | Annotated[list[TextPart], Field(min_length=1)]


def text(value):
    if isinstance(value, str):
        return value
    return '\n'.join(part.text if isinstance(part, TextPart) else part['text'] for part in value)


class Message(BaseModel):
    model_config = ConfigDict(extra='forbid')
    role: Nonempty
    content: Content
    timestamp: int | None = Field(default=None, strict=True)

    @field_validator('content')
    @classmethod
    def nonblank(cls, value):
        if not text(value).strip():
            raise ValueError('blank_content')
        return value


class Add(BaseModel):
    model_config = ConfigDict(extra='forbid')
    request_id: Nonempty
    user_id: Nonempty
    session_id: Nonempty
    messages: list[Message] = Field(min_length=1)

    @field_validator('request_id', 'user_id', 'session_id')
    @classmethod
    def nonblank(cls, value):
        if not value.strip():
            raise ValueError('blank_identity')
        return value

    def retrieval_payload(self):
        value = self.model_dump()
        for message, original in zip(value['messages'], self.messages):
            message['content'] = text(original.content)
        return value


class Search(BaseModel):
    model_config = ConfigDict(extra='forbid')
    user_id: Nonempty
    query: Content
    options: list[StrictStr] | None = None
    top_k: int = Field(ge=1, le=100, strict=True)

    @field_validator('user_id')
    @classmethod
    def nonblank_user(cls, value):
        if not value.strip():
            raise ValueError('blank_identity')
        return value

    @field_validator('query')
    @classmethod
    def nonblank_query(cls, value):
        if not text(value).strip():
            raise ValueError('blank_query')
        return value

    def retrieval_payload(self):
        return dict(self.model_dump(), query=text(self.query))


class EnvelopeJournal:
    """Reserve original envelopes before work; append completion only after commit.

    A crash leaves an immutable pending envelope that can be repaired by the
    same logical retry. A different envelope under that identity is a conflict,
    even if flattening happens to produce the same retrieval text.
    """
    def __init__(self, raw_path):
        self.path = Path(str(raw_path) + '.envelopes.sqlite3')
        with closing(self.connect()) as db:
            db.executescript('''
                CREATE TABLE IF NOT EXISTS envelopes(
                    user_id TEXT NOT NULL,request_id TEXT NOT NULL,
                    fingerprint TEXT NOT NULL,body TEXT NOT NULL,
                    PRIMARY KEY(user_id,request_id));
                CREATE TABLE IF NOT EXISTS completions(
                    user_id TEXT NOT NULL,request_id TEXT NOT NULL,
                    fingerprint TEXT NOT NULL,PRIMARY KEY(user_id,request_id));
                CREATE TRIGGER IF NOT EXISTS envelopes_no_update BEFORE UPDATE ON envelopes
                    BEGIN SELECT RAISE(ABORT,'immutable_envelope'); END;
                CREATE TRIGGER IF NOT EXISTS envelopes_no_delete BEFORE DELETE ON envelopes
                    BEGIN SELECT RAISE(ABORT,'immutable_envelope'); END;
                CREATE TRIGGER IF NOT EXISTS completions_no_update BEFORE UPDATE ON completions
                    BEGIN SELECT RAISE(ABORT,'append_only'); END;
                CREATE TRIGGER IF NOT EXISTS completions_no_delete BEFORE DELETE ON completions
                    BEGIN SELECT RAISE(ABORT,'append_only'); END;
            ''')
            db.commit()

    def connect(self):
        return sqlite3.connect(self.path, timeout=60)

    def add(self, payload, store):
        normalized = payload.retrieval_payload()
        # On migration an older committed Add may have no envelope journal.
        # Reject a conflicting body before it can reserve that old identity.
        legacy_fingerprint = digest(dict(session_id=payload.session_id, messages=normalized['messages']))
        with closing(store.connect()) as db:
            legacy = db.execute('SELECT payload_hash FROM requests WHERE user_id=? AND request_id=?',
                                (payload.user_id, payload.request_id)).fetchone()
        if legacy is not None and legacy[0] != legacy_fingerprint:
            raise ConflictError('Request ID conflicts with committed source')
        body = json.dumps(payload.model_dump(), sort_keys=True, ensure_ascii=False, separators=(',', ':'))
        fingerprint = hashlib.sha256(body.encode('utf-8')).hexdigest()
        identity = payload.user_id, payload.request_id
        with closing(self.connect()) as db:
            db.execute('INSERT OR IGNORE INTO envelopes VALUES(?,?,?,?)', (*identity, fingerprint, body))
            previous = db.execute('SELECT fingerprint,body FROM envelopes WHERE user_id=? AND request_id=?',
                                  identity).fetchone()
            if previous != (fingerprint, body):
                raise ConflictError('Request ID conflicts with original envelope')
            db.commit()
        count = store.add(**normalized)
        # store.add includes the SQLite source/chunk commit and scope revision.
        # Completion is deliberately after that boundary, never a queue receipt.
        with closing(self.connect()) as db:
            db.execute('INSERT OR IGNORE INTO completions VALUES(?,?,?)', (*identity, fingerprint))
            previous = db.execute('SELECT fingerprint FROM completions WHERE user_id=? AND request_id=?',
                                  identity).fetchone()
            if previous != (fingerprint,):
                raise ConflictError('Completion identity conflict')
            db.commit()
        return count
