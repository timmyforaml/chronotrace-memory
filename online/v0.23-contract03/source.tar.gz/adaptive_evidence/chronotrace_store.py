"""Independent append-only derivations over immutable official source storage."""
from contextlib import closing
from contextvars import ContextVar
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import sqlite3
import threading

from .core import MemoryStore as BaselineStore, digest
from .chronotrace_state import REVISION, parse_source, query_view, annotation, project

QUERY = ContextVar('chronotrace_query', default=None)


class DerivedStore:
    def __init__(self, path):
        self.path = Path(path)
        self.lock = threading.RLock()
        with closing(self.connect()) as db:
            db.executescript('''
                CREATE TABLE IF NOT EXISTS objects(
                  id TEXT PRIMARY KEY, kind TEXT NOT NULL, body TEXT NOT NULL,
                  inserted_at TEXT NOT NULL);
                CREATE TRIGGER IF NOT EXISTS objects_no_update BEFORE UPDATE ON objects
                  BEGIN SELECT RAISE(ABORT,'append_only'); END;
                CREATE TRIGGER IF NOT EXISTS objects_no_delete BEFORE DELETE ON objects
                  BEGIN SELECT RAISE(ABORT,'append_only'); END;
            ''')
            db.commit()

    def connect(self):
        return sqlite3.connect(self.path, timeout=60)

    def put(self, kind, body):
        identity = digest([kind, body])
        encoded = json.dumps(body, sort_keys=True, ensure_ascii=False, separators=(',', ':'))
        with self.lock, closing(self.connect()) as db:
            db.execute('INSERT OR IGNORE INTO objects VALUES(?,?,?,?)',
                       (identity, kind, encoded, datetime.now(timezone.utc).isoformat()))
            existing = db.execute('SELECT kind,body FROM objects WHERE id=?', (identity,)).fetchone()
            if existing != (kind, encoded):
                raise ValueError('derived_object_integrity_failure')
            db.commit()
        return identity


class MemoryStore(BaselineStore):
    def __init__(self, path, encoder, config=None, **kwargs):
        super().__init__(path, encoder, config, **kwargs)
        self.derived = DerivedStore(str(self.path) + '.chronotrace.sqlite3')

    def derive(self, source):
        anchor = dict(source_id=source['id'], user_id=source['user_id'],
                      source_sha256=hashlib.sha256(source['content'].encode('utf-8')).hexdigest(),
                      source_record_time_ms=source['timestamp'], revision=REVISION)
        frames = parse_source(source['id'], source['content'], source['role'], source['timestamp'])
        identity = self.derived.put('source_derivation', dict(anchor=anchor, frames=frames))
        return dict(anchor=anchor, frames=frames, derivation_id=identity)

    def add(self, **kwargs):
        count = super().add(**kwargs)
        # An idempotent retry repairs an interrupted sidecar derivation without
        # rewriting the official source or changing the original Add identity.
        with closing(self.connect()) as db:
            rows = db.execute('SELECT * FROM sources WHERE user_id=? AND request_id=?',
                              (kwargs['user_id'], kwargs['request_id'])).fetchall()
        for row in rows:
            self.derive(dict(row))
        return count

    def search(self, **kwargs):
        context = dict(user_id=kwargs['user_id'], view=query_view(kwargs['query']), sources={})
        token = QUERY.set(context)
        try:
            return super().search(**kwargs)
        finally:
            QUERY.reset(token)

    def render(self, row):
        original = super().render(row)
        context = QUERY.get()
        if context is None:
            return original
        sid = row['source_id']
        if sid not in context['sources']:
            with closing(self.connect()) as db:
                raw = db.execute('SELECT * FROM sources WHERE id=? AND user_id=?',
                                 (sid, context['user_id'])).fetchone()
            if raw is None:
                raise ValueError('missing_original_source')
            context['sources'][sid] = self.derive(dict(raw))
        derived = context['sources'][sid]
        notes = []
        for frame in derived['frames']:
            start, end = frame['source_span']
            if row['start'] <= start and end <= row['end']:
                note = annotation(frame, context['view'])
                notes.append(note)
                projection = dict(derivation_id=derived['derivation_id'], span=frame['source_span'],
                                  view=context['view'], projection=project(frame, context['view']))
                # A per-search set avoids repeated disk writes while the official
                # packer considers the same source under several budget choices.
                key = digest(projection)
                if key not in context:
                    self.derived.put('query_projection', projection)
                    context[key] = True
        # Included in the ORIGINAL packer's character accounting. Source span is
        # retained verbatim. Nothing is appended after packing.
        return ('\n'.join(notes) + '\n' if notes else '') + original
