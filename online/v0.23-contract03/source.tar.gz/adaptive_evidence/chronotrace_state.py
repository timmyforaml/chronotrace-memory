"""Source-local assertion extents, not a cross-message lexical update chain.

No claim is assigned to the account owner. First person is an opaque narrator
within this source. Unsupported grammar has no derived representation.
"""
from __future__ import annotations

from datetime import date
import re

REVISION = "source-local-extents-01"
ATTRS = {
    "address": "address", "email address": "email", "phone number": "phone",
    "job title": "job_title", "employer": "employer", "home city": "residence",
}
PREDICATES = {
    "live in": ("residence", "live in", "lives in"),
    "work at": ("employer", "work at", "works at"),
    "work as": ("job_title", "work as", "works as"),
}
ACTOR = r"(?:I|[A-Z][a-z]+(?: [A-Z][a-z]+){0,2})"
OWNER = r"(?:My|[A-Z][a-z]+(?: [A-Z][a-z]+){0,2}'s)"
VALUE = r"[^\n.!?;\"“”]{1,100}?"
ISO = r"\d{4}-\d{2}-\d{2}"
CHANGE = re.compile(
    rf"(?P<owner>{OWNER}) (?P<attr>{'|'.join(ATTRS)}) changed from "
    rf"(?P<old>{VALUE}) to (?P<new>{VALUE})(?: on (?P<date>{ISO}))?[.!]?$")
CORRECTION = re.compile(
    rf"(?:Correction|To correct my earlier statement): (?P<owner>{OWNER}) "
    rf"(?P<attr>{'|'.join(ATTRS)}) is (?P<new>{VALUE}), not (?P<old>{VALUE})[.!]?$")
TRANSITION = re.compile(
    rf"(?P<actor>{ACTOR}) used to (?P<pred>{'|'.join(PREDICATES)}) (?P<old>{VALUE}), "
    rf"but now (?P<actor2>{ACTOR}) (?P<pred2>live in|lives in|work at|works at|work as|works as) "
    rf"(?P<new>{VALUE})(?: since (?P<date>{ISO}))?[.!]?$")
# Full-line matching deliberately avoids interpreting quoted, hypothetical or
# embedded claims. Speaker labels are explicit source text, never inferred.
SPEAKER = re.compile(r"(?P<speaker>[A-Z][a-z]+(?: [A-Z][a-z]+){0,2}): (?P<body>.*)$")


def valid_date(value):
    if value is None:
        return None
    return date.fromisoformat(value).isoformat()


def parse_source(source_id, content, role, record_time):
    frames = []
    offset = 0
    for line in content.splitlines(keepends=True):
        stripped = line.strip()
        start = offset + len(line) - len(line.lstrip())
        offset += len(line)
        speaker, body = None, stripped
        prefix = SPEAKER.fullmatch(stripped)
        if prefix and prefix['speaker'] not in {'Correction'}:
            speaker, body = prefix['speaker'], prefix['body']
        match = CHANGE.fullmatch(body)
        kind = "transition"
        if match:
            values = match.groupdict()
            actor = values['owner']
            field = ATTRS[values['attr']]
        else:
            match = TRANSITION.fullmatch(body)
            if match:
                values = match.groupdict()
                if values['actor'] != values['actor2']:
                    continue
                spec = PREDICATES[values['pred']]
                # Both clauses must have the same exact predicate family.
                if values['pred2'] not in spec[1:]:
                    continue
                actor, field = values['actor'], spec[0]
            else:
                match = CORRECTION.fullmatch(body)
                if not match:
                    continue
                values, kind = match.groupdict(), "correction"
                actor, field = values['owner'], ATTRS[values['attr']]
        old, new = values['old'].strip(), values['new'].strip()
        # No temporal or negated/modal clauses may hide in an object literal.
        if old == new or any(re.search(r"\b(?:if|would|could|might|not|never|but|since|until|on \d{4})\b", v, re.I)
                             for v in (old, new)):
            continue
        try:
            boundary = valid_date(values.get('date'))
        except ValueError:
            continue
        actor_key = "literal:" + actor
        if actor in {'I', 'My'}:
            actor_key = "explicit-speaker:" + speaker if speaker else "source-narrator:" + source_id
        frames.append({
            "revision": REVISION, "source_id": source_id,
            "source_span": [start, start + len(stripped)],
            "actor": actor_key, "actor_text": speaker if actor in {'I', 'My'} and speaker else actor,
            "field": field, "scope": "source-local:" + source_id,
            "kind": kind, "old": old, "new": new,
            "effective_boundary": boundary, "record_time_ms": record_time,
            "record_role": role,
            "old_semantics": "prior_state_as_stated" if kind == "transition" else "retracted_alternative_not_prior_state",
        })
    return frames


def query_view(query):
    q = query.casefold()
    # Exact dates and year ranges remain ranges, not a fabricated question-now.
    dates = re.findall(r"\b\d{4}-\d{2}-\d{2}\b", query)
    if len(dates) == 1:
        try:
            d = valid_date(dates[0])
            return {"mode": "as_of", "start": d, "end": d}
        except ValueError:
            return {"mode": "unresolved_time"}
    if len(dates) > 1:
        return {"mode": "history"}
    years = re.findall(r"\b(?:19|20)\d{2}\b", query)
    if len(years) == 1:
        return {"mode": "as_of", "start": years[0] + "-01-01", "end": years[0] + "-12-31"}
    if re.search(r"\b(?:history|over time|changed|changes|timeline)\b|历史|变化|变迁", q):
        return {"mode": "history"}
    if re.search(r"\b(?:now|currently|current|today|present)\b|现在|目前|当前", q):
        return {"mode": "current_as_stated"}
    if re.search(r"\b(?:previously|before|formerly|used to|past|earlier)\b|过去|以前|曾经", q):
        return {"mode": "prior_as_stated"}
    return {"mode": "unspecified"}


def project(frame, view):
    mode, boundary = view['mode'], frame['effective_boundary']
    if frame['kind'] == 'correction':
        # A correction of a claim is not evidence that the old value ever held.
        return {"selected": ["replacement_claim"], "excluded": ["retracted_alternative"],
                "temporal_status": "valid_time_unknown"}
    if mode == 'as_of':
        if boundary is None:
            return {"selected": ["prior", "later"], "temporal_status": "unresolved_boundary"}
        selected = []
        if view['start'] < boundary:
            selected.append('prior')
        if view['end'] >= boundary:
            selected.append('later')
        return {"selected": selected, "temporal_status": "source_stated_extents"}
    if mode == 'prior_as_stated':
        return {"selected": ["prior"], "temporal_status": "prior_relative_to_this_statement"}
    if mode == 'current_as_stated':
        return {"selected": ["later"], "temporal_status": "current_in_this_statement_query_now_unverified"}
    return {"selected": ["prior", "later"], "temporal_status": "source_stated_order"}


def annotation(frame, view):
    result = project(frame, view)
    # Compact, declarative evidence metadata; no generated answer or imperative.
    entries = ["ChronoTrace derived", "source=" + frame['source_id'][:16],
               "span=" + ':'.join(map(str, frame['source_span'])),
               "actor=" + frame['actor_text'], "field=" + frame['field'],
               "query_view=" + view['mode'], "status=" + result['temporal_status']]
    if frame['kind'] == 'correction':
        entries += ["replacement_claim=" + frame['new'], "retracted_alternative=" + frame['old'],
                    "past_reality=unestablished"]
    else:
        entries += ["prior=" + frame['old'], "later=" + frame['new'],
                    "effective_boundary=" + (frame['effective_boundary'] or 'unknown'),
                    "selected=" + ','.join(result['selected'])]
    return '[' + '; '.join(entries) + ']'
